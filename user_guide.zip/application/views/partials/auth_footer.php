<div class="spacer-100"></div>
<div class="row">
	<div class="col-xs-12">
		<div class="footer text-center">
			Copyright &copy; 2018
		</div>
	</div>
</div>
<!-- container ends -->
 <script src="<?=base_url('assets/js/jquery.js')?>"></script>
 <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.14.0/jquery.validate.min.js"></script>
 <script> jQuery("form").validate(); </script>
 </body>
</html>
				

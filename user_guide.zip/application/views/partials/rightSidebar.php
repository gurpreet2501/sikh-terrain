	<a href="<?=site_url('search');?>"><img src="<?=base_url()?>/images/book-appointment.png" class="text-center" /></a>
		<div class="panel-group" role="tablist">
	    <div class="panel panel-default">
	        <div class="panel-heading" role="tab" id="collapseListGroupHeading1">
	            <h4 class="panel-title"> <a href="#collapseListGroup1" class="" role="button" data-toggle="collapse" aria-expanded="true" aria-controls="collapseListGroup1">District Health</a> </h4> </div>
	         <div class="panel-collapse collapse in" role="tabpanel" id="collapseListGroup1" aria-labelledby="collapseListGroupHeading1" aria-expanded="true">
	            <ul class="list-group">
									<a class="page-anchors" href="<?=site_url('page/health-profile')?>"><li class="list-group-item">Health Profile</li></a>
									<a class="page-anchors" href="<?=site_url('page/district-blindness-control-society')?>"><li class="list-group-item">Distt Blindness Control Society</li></a>
									<a class="page-anchors" href="<?=site_url('page/revised-national-tb-control-programme')?>"><li class="list-group-item">Revised National TB Control Programme</li></a>
									<a class="page-anchors" href="<?=site_url('page/blood-donors-of-the-district')?>"><li class="list-group-item">Blood Donors of the District</li></a>
	            </ul>
	        </div>
	    </div>
	    <div class="panel panel-default">
	        <div class="panel-heading" role="tab" id="collapseListGroupHeading1">
	            <h4 class="panel-title"> <a href="#collapseListGroup1" class="" role="button" data-toggle="collapse" aria-expanded="true" aria-controls="collapseListGroup1">Public Utility Services </a> </h4> </div>
	         <div class="panel-collapse collapse in" role="tabpanel" id="collapseListGroup1" aria-labelledby="collapseListGroupHeading1" aria-expanded="true">
	            <ul class="list-group">
										<li class="list-group-item"><a href="<?=site_url('page/about-suwidha')?>">About Suwidha</a></li>
										<li class="list-group-item"><a href="<?=site_url('page/public-utility-forms')?>">Public Utility Forms</a></li>
										<li class="list-group-item"><a href="http://passportstatus.nic.in/">Passport Status</a></li>
										<li class="list-group-item"><a href="<?=base_url('pdfs/leadbankdata.pdf')?>">Service Area Plan (Bank)</a></li>
										<li class="list-group-item"><a href="<?=site_url('page/egovernance')?>">E-Governance at Patiala</li>
	            </ul>
	            
	        </div>
	    </div>
</div>


<nav class="collapse navbar-collapse pull-right" id="mainmenu">
	<ul class="nav navbar-nav scrollnav">
		<li class="active"><a href="/">Home</a></li>
		<li><a href="/#about">About us</a></li>
		<li><a href="/#attractions">Attraction</a></li>
		<li>
			<a href="/#tourists">Gallery</a>
			<ul>
				<li><a href="blog.html">Find Us</a></li>
				<li><a href="blog.html">Attraction</a></li>
				<li><a href="blog.html">Timings</a></li>
				<li><a href="blog.html">Visitor Policies</a></li>
				<li><a href="blog.html">FAQ</a></li>
				<li><a href="blog.html">Feedback</a></li>
			</ul>
		</li>
		<li><a href="/#museum">Museum</a></li>
	</ul>
</nav><!--/#mainmenu-->
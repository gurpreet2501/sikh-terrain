<?php $this->load->view('partials/header'); ?>
  <!-- Start main-content -->
  <div class="main-content">
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-9 blog-pull-right">
            <div class="single-service">
              <h3 class="text-theme-colored line-bottom text-theme-colored">ADCA</h3>
                <ul class="review_text list-inline">
                  <li>
                    <div class="star-rating" title="Rated 4.50 out of 5"><span style="width: 90%;">4.50</span></div>
                  </li>
                </ul>
               <p> 
                  <ul>
                    <li>MS-Excel, MS-Word, MS-PowerPoint</li>
                    <li>MS-Dos, MS-Windows, MS-Access</li>
                    <li>Basic Concepts of Accounts</li>
                    <li>Maintaining Ledgers, Cash Book</li>
                    <li>Balance Sheet, Profit &amp; Loss</li>
                    <li>Financial Accounting (Tally)</li>
                    <li>C Language, C++ Language, Foxpro</li>
                    <li>HTML, JAVA SCRIPT</li>
                    <li>FRONT PAGE</li>
                    <li>Complete Internet</li>
                    <li>Photo Editing Softwares</li>
                    <li>Computer Fundamentals</li>
                    <li>Basics of Computer Hardware</li>
                    <li>Virus Protection &amp; Scanning</li>
                    <li>Software Installation</li>
                  </ul>
                  <h3>Duration</h3>
                  DURATION: - 3 MONTHS
                  <!-- COURSE DURATION:- 3 MONTHS -->
                          <!-- PAYABLE IN MONTHLY  -->
			         </p>
            </div>
          </div>
          <div class="col-sm-12 col-md-3">
             <?php $this->load->view('partials/sidebar'); ?>
          </div> <!-- col-sm-12 -->
        </div> <!-- row -->
      </div>
    </section>
  </div>
  <!-- end main-content -->
<?php $this->load->view('partials/footer'); ?>
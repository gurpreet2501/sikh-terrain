<?php 

$config['errors'] = [
	101 => 'Unable to insert in database',
	102 => 'No machine binding exits for this card',
	103 => 'This card is not attached with this machine',
	104 => 'Either card or machine not present in database',
	105 => 'Machine is not enabled so you cant mark attendence',
	106 => 'Student does not assocoated with this card',
	107 => 'Attendence Already Marked',
];


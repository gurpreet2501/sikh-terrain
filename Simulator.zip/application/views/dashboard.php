<?php $this->load->view('admin/partials/header'); ?>
<div class="row">
	<div class="col-xs-12">
<br>
<br>
		<h2 class="text-center">SIKH TERRAIN ADMIN PANEL</h2>
	</div>
	<div class="col-xs-6">
		
	</div><!-- col-xs-6 -->

	<div class="col-xs-6">

	</div>



</div>
<?php $this->load->view('admin/partials/footer'); ?>